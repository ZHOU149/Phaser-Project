<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.9" tiledversion="1.9.0" name="dungeontileset" tilewidth="32" tileheight="32" tilecount="112" columns="4">
 <image source="Dungeon.png" width="128" height="896"/>
</tileset>
