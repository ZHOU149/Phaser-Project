<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.9" tiledversion="1.9.0" name="factorytileset" tilewidth="32" tileheight="32" tilecount="416" columns="26">
 <image source="factorytileset.png" width="832" height="512"/>
</tileset>
