<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.9" tiledversion="1.9.0" name="scifitileset" tilewidth="32" tileheight="32" tilecount="851" columns="37">
 <image source="scifitileset.png" width="1184" height="736"/>
</tileset>
